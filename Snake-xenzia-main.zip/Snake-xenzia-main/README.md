# Snake-xenzia

Snake game implemented using Html Css and JS


### Things to learn
- [X] Basic JS Game rendering techniques
- [X] Basic Html,Css



### Things to add
- [ ] Complete the game
- [ ] difficulty levels not working
- [x] game not over on collision on wall
- [ ] snake starts from 0 0 after collision from wall
- [x] sounds not working
- [x] change direction of keys from r, l, d, u to arrow keys
- [x] add custom message on game over





